﻿namespace Subway.POS.FiscalIntegration
{
    public enum DeviceStatusType
    {
        FiscalBoardOnly,
        FiscalBoardAndPrinter,
        Flash
    }
}
