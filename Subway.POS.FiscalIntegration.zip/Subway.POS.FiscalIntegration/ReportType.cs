﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Subway.POS.FiscalIntegration
{
    public enum ReportType
    {
            XReport,
            LastReceiptReprint,
            Zreport,
            PeriodicalReportExtended,
            PeriodicalReportCondensed,
            ClosurePeriodicalReportExtended,
            ClosurePeriodicalReportCondensed,
            PMXReport,
            EJReport,
            ReceiptReprint

    }
}
