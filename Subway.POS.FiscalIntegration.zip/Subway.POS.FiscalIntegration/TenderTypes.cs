﻿namespace Subway.POS.FiscalIntegration
{
    public enum TenderType
    {
        CASH,
        CARD,
        CHEQUE,
        VOUCHER,
        OTHER,
        CREDIT
    }
}
