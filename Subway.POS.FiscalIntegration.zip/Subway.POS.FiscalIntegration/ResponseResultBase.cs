﻿namespace Subway.POS.FiscalIntegration
{
    public  class ResponseResultBase
    {
        public Status Response { get; set; }

    }
}
